def salvararquivo(producto):

  arquivo = open('Produtos_salvo.txt','r')
  produtos_salvos = arquivo.readlines()
  arquivo.close()

  id = str(producto.obterId()) 
  for linha in produtos_salvos:
    if id in linha:
      print(f"ERROR Produto com ID {id} já existe.")
      return False 

  arquivo = open('Produtos_salvo.txt', 'a')
  id = 'id: ' + str(producto.obterId())
  nome = 'nome: ' +  str(producto.obterName())
  quantidade = 'quantidade: ' + str(producto.obterQuantid())
  valor = 'valor: ' + str(producto.obterValor())
  status = 'Status: ' + str(producto.obterStatus())
  lista = [ id, '\n', nome,'\n', quantidade,'\n', valor,'\n', status, '\n',]
  arquivo.write(str(lista))
  arquivo.close()
  return True


 