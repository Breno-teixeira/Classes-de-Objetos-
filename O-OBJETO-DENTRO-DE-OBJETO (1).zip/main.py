import classes as pedrinha
import generico

problema = pedrinha.producto()
gotica = 0


while True:
    try:
        gotica = int(input('''
        
        Selecione uma das opções:
        
        |--------------------------|
        | 1 - Criar um produto     |
        | 2 - Mostrar produto      |
        | 3 - Salvar no sistema    |
        | 4 - Sair                 |
        |--------------------------|
        '''))
    except:
      print('Valor inválido, tente novamente!')

      if gotica == 1:
            nome = input('Insira o nome do produto: ')
            id = input('Insira o id do produto: ')
            quantidade = input('Insira a quantidade do produto: ')
            valor = input('Insira o valor do produto: ')
            status = True
            print('Adicionando um novo produto')

            problema.setNome(nome)
            problema.setId(id)
            problema.setQuantidade(quantidade)
            problema.setValor(valor)
            problema.setStatus(status)

      elif gotica == 2:

          print(f'''
          - Produto: -
  Nome: {problema.obterName()}
  Id: {problema.obterId()}
  Quantidade: {problema.obterQuantid()}
   Valor: {problema.obterValor()}
          ''')

        
      elif gotica == 3:
         try:
            generico.salvararquivo(problema)
         except ValueError:
          print('''Não foi possivel encontrar um produto!''')
      
      elif gotica == 4:
            print("Finalizando Sistema.")
            break



#https://youtu.be/2KTXZazwSgE #
# https://youtu.be/2KTXZazwSgE?si=c6mZ-tEsFTCJ3dLZ
