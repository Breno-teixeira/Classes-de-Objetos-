class producto:
 
  def __int__(self, nome = 'chocolate', id = 0, quantidade = 10, valor = 10.90, status = False):
    
    self.nome = nome 
    try:
      self.id = int(id)
    except:
      self.id = 0
      
    self.quantidade = quantidade
    self.valor = valor 
    self.status = status

  def obterName(self):
    return self.nome

  def obterId(self):
    return self.id 

  def obterQuantid(self):
    return self.quantidade

  def obterValor(self):
    return self.valor

  def obterStatus(self):
    return self.status

  def setNome(self, novoNome):
    self.nome = novoNome
    return True

  def setId(self, novoid):
    self.id = novoid
    return True
   
  def setQuantidade(self, novoQuan):
    self.quantidade = novoQuan
    return True

  def setValor(self, novovalor):
    self.valor = novovalor
    return True

  def setStatus(self, novostatus):
    self.status = novostatus
    return True

  